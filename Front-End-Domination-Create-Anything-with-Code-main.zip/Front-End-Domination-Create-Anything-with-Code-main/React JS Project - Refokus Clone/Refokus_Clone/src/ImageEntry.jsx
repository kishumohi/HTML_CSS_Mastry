// export { work1 } from "./assets/work_1.png";
// export { work2 } from "./assets/work_2.png";
// export { work3 } from "./assets/work_3.png";
// export { work4 } from "./assets/work_4.png";
