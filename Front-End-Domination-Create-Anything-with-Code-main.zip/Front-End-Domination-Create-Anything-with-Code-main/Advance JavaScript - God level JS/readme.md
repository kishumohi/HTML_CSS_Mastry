Prototypal Inheritance
Closures
Event Delegation
Higher-Order Functions
Error Handling (try...catch blocks)
Custom Events
Understanding this
call apply bind
