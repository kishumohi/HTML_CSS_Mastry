// content

// DOM

// DOM Manipulation

// Accessing Elements:
//      document.querySelector()

// Modifying Elements:
//      innerHTMl, textContent

// Manipulating Styles and Classes:
//    style
//    classList

// Creating and Deleting Elements:
// createElement()
// appendChild()
// removeChild()

// Event Handling:
//    addEventListener()

// Event Object
