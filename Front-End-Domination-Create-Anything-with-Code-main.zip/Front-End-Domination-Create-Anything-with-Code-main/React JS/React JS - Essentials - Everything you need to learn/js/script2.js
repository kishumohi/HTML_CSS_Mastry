// import Cart from "./script";
import { Cart } from ".script.js";

// console.log(Cart);
