import React from "react";

const ReactForm = () => {
  return (
    <div>
      <h5>React Form</h5>
    </div>
  );
};

export default ReactForm;
