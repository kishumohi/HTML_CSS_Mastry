import React from "react";

const Details = () => {
  return <div>Details</div>;
};

export default Details;
