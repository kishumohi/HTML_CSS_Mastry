import React from "react";

const Contact = () => {
  return (
    <div>
      <h5>Contact</h5>
      <form>
        <input type="text" placeholder="Name" /> <br />
        <input type="email" placeholder="email" />
      </form>
    </div>
  );
};

export default Contact;
