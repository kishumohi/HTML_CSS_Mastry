import React from "react";

const About = () => {
  return (
    <div>
      <h3>About</h3>
      <p>I am frontEnd Developer and developing WEb application</p>
    </div>
  );
};

export default About;
