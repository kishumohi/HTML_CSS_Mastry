import "./App.css";
import Card from "./components/Card";

function App() {
  return (
    <div>
      {/* <h1>App</h1> */}
      {/* <Header />
      <About />
      <Contact /> */}
      <Card />
    </div>
  );
}

export default App;
