// window

// browser mein inbuilt hota hai

// there are many features which are frequently used in js and they are not the part of js, they are not the part of js the language but they are available in the browser, and when you use them in js they are called from browser and not js

// window ek bucket samajh lo jismein saari wo cheejein available hai jo browser deta hai js mein use krne ke liye kyoki wo saari cheejein js ka part nahi balki browser ka part hai which is available to use in js, we can also they're provided by browser to use in js, all these features which are made available via browser are put inside window

// alert
// document
// prompt
// console
// confirm

console.log(window);
