// js the language

// js - breiden eich
// managed by ECMA
// naye features, puraane hatana, kharab features shi krna

// js the language = code likhna seekhna, main features
// js the dom = code likhkar cheejein banana seekhna

// js the DOM - creating

// basics

//  basics = file connect karenge and load karnge script ko, basics of code execution, grammar and understanding of errors

// var a = 12;
// var b = 22;

// console.log("Basics of JS");

// kaha ho bhai chalo ghar
// ho ghar bhai chalo kaha

// grammar of js

// you can have all the tools in your box & grammar is like ability to use them

// you deal can me with
// you can deal with me

// var a = 12;

// var = 2;

// error check in console

// inbult features

// console
// alert
// prompt
// confirm

// console.log("Hello");
// console.error("error");
// console.warn("warning comes");

// alert("message box");

// var a = prompt("enter value");

// console.log(a);

var a = confirm("you are learning js.???");

if (a) {
  console.log("congrats for learning JS");
} else {
  console.error("You are not learning JS");
}

// variables constants
// compilers & interpreters
// window
// types
// conditionals
// loops
// functions
// return
// undefined not defined null
// arrays
// objects
// questions

// prototypes
// prototypal inheritance
// asynchronous synchronous js
// es6 climax
// questions

// miscellaneous - switch case and ternary do-while forin forof

// interview prep

// call apply bind
// this
// prototypal inheritance
