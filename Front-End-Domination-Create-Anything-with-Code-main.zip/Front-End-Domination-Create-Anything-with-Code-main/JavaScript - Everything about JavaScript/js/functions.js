// functions - js mein function normal programming language jaise nahi hai, iska matlab hai yaha par js mein , functions banaane ke liyein type nahi batana padta bas aapko function word likhna padega and aap usey koi naam deke bana skte ho

// indepth - js mein functions first class functions ka darja diya gaya hai, jiska matlab hai, ki js mein functions ko value/ variable ki tarah treat kiya ja sakta hai

// what is function

// koi esa code jo aapko baar baar use krna ho, ya fir ki aisa code jisko turant na chalana ho par kabhi chalana ho, usey function mein daal skte hai

// console.log("bartan uthao");

// console.log("chaawal daalo");

// console.log("paani daalo");
// console.log("gas par chadao for 20 mins");

// console.log("gas off krke thanda hone do");
// console.log("Khaalo");

// function abcd() {
//   console.log("bartan uthao");

//   console.log("chaawal daalo");

//   console.log("paani daalo");
//   console.log("gas par chadao for 20 mins");

//   console.log("gas off krke thanda hone do");
//   console.log("Khaalo");
// }

// abcd();

// abcd();

// var dateOfBirth = 14;

// var todaysDate = 14;

// function happyBirthday() {
//   console.log("happy birthday");
// }

// if (dateOfBirth === todaysDate) {
//   happyBirthday();
// }

// why we need

// to reuse code and to wrap the code which we want to run in future at some point of time

// how to use

// function abcd() { you code}

// extrass we should know

// paramters and arguments

// function abcd(num){}  // parameter receive

// abcd(12)   // argument pass

// es 5 vs es6

// es5 - fucntion statements,function expressions, anonymous fucntion

// es6 - fat arrow function

// a) basic fat arrow
// b) fat arrow with one param
// c) fat arrow with implicit return

// function abcd(param) {}

// prep for interview

// function statement

// function abcd(){
// function statement
// }

// function expression

// var abcd = function(){}

// anonymous function

// function(){}

//fat arrow

// ()=>{}

// var a = ()=>{};
// var b = ()=>{};

// fat arrow with one param

// var c = (a)=>{console.log(a)};

// fat arrow with param implicit return

// var g = ab=>ab;

// g(12)

// var abcd = () =>34;

// var ans = abcd()

// return ka matlab hua, jaha par bhi return lagega uske aage jo bhi likhoge wo jaayega jaha par function call hua tha, return functions ke andar lagta hai

// esa function jo kuch return nahi krta woh  bhi undefined return krta hai

// function abcd() {
//   return 12;
// }

// var res = abcd();

// console.log(res);

// var a = () => {
//   return 12;
// };

// var res = a();

// console.log(res);
