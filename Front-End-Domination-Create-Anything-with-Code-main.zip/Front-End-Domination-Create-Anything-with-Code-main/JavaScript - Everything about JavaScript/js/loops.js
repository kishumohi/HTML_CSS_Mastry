// loops

// repetetion of any task

// particular condition

// loops = repeat

// 1 1 1 1 1 1 1

// 1 2 3 4 5 6 7 8

// for while do-while foreach forin forof

// for while forEach

// foreach ek normal loop nahi hai for anad while ki tarah jo numbers pe ya start end par chalta hai,, foreach loop sirf array pe chalta hai

// for (let i = 0; i < 4; i++) {
//   console.log(i);
// }

// for(start;end;change){

// }

// for (var num = 5; num < 10; num++) {
//   console.log(num);
// }

// outside bhi access kr skte hai num ki value

// console.log(num);

// num++;

// console.log(num);

// 20 - 5

// for (var i = 20; i > 4; i--) {
//   console.log(i);
// }

// while

// start;
// while(end){
// change;
// }

// let i = 10;

// while (i < 20) {
//   console.log(i);
//   i++;
// }

// 1 - 10

// var i = 1;

// while (i < 11) {
//   console.log(i);
//   i++;
// }

// 20 - 30

// var i = 20;

// while (i < 31) {
//   console.log(i);
//   i++;
// }

// 32 - 45

// var i = 32;

// while (i < 46) {
//   console.log(i);
//   i++;
// }

// 45 - 32

// var i = 45;

// while (i > 31) {
//   console.log(i);
//   i--;
// }

// 12 - 1

// var i = 12;

// while (i > 0) {
//   console.log(i);
//   i--;
// }

// glory with loops

// try to create basic loop structure

// try to conquer basic loop structure ranging from one num to another
