// compiler vs interpreter

// js language english wwords use krti hai and computers english nahi samjhte, wo samjhte hai 0 and 1 jisko current flow and current bypass bhi kah sakte ho, and hum chahte hai hum english mein likhke computer se baat krle, to hum ek translator lagaayege jo ki humara code english mein lega and use 0 and 1 mein convert kr dega,

// compiler and interpreter translators hai jo ki english code ko convert kr rhe hai machine code mein js mein interpreter hota hai

// java - compiler

// jit compiler - just in time (google)

// interpreter ki shuraati taakat use krta hai and compiler ki running taakat use krta hai
