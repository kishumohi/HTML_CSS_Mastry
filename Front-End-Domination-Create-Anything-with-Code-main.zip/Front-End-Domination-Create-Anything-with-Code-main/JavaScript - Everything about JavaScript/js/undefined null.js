// undefined is a value
// ye value tab di jaati hai jab variable ko koi value naa mili ho, iska matlab hai, ye ek garbage value ki tarah treat ki jaati hai, aap isey default value bhi kah skte ho

// var a = 12;
// var b;

// console.log(a);

// console.log(b);

// not defined is an error

// koi particular element/identity ko use karna without it's declaration gives an error, and that error is not defined error

// console.log(b); // get error

// null is also a value
// this is a value which resolve like, not found
// null is received when something is not found

var b = null;
console.log(b);
