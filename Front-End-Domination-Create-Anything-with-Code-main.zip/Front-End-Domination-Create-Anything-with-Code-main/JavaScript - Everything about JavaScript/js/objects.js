// objects

// what

// object ek tareek hai jisse ki hum ek identity ki details ko ek saath rakh skt hai

// object = ek bande ka kai saara data
// array = kai logo ka data

var obj = {
  name: "lucky",
  age: 23,
  work: "developer",
  address: "Kalindi Vihar,Agra",
};

// var obj2 = new Object();

// console.log(obj, obj2);

// console.log(obj);

console.log(obj.name);
console.log(obj.work);

var battery = {
  company: "canon",
  price: 1200,
  for: "camera",
  isWorking: true,
};

console.log(battery.price);

// console.log(console);  // console object

// how

// {}

// when & why

// jab bhi apko ek hi element ki bhut saari details store krni ho

// to save a lot of details all together at one place we use object
