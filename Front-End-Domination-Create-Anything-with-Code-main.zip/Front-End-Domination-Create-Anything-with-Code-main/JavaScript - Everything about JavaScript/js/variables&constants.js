// variables & constants hate hai data store krne ke liyein & variables mein data store hota hai and change bhi ho jaata hai and constants mein data store and change nahi hota and dono hi browser par memory lete hai and browser RAM par chalta hai to technically dono RAM par chalte hai ya fir space lete hai

// har programming lang mein data se deal karna hota hai,
// wo alag alag prakaar ka data ho sakta hai, ab aisa data
// jisse humein deal karna hai, wo save to karna pdega na,
// to wo data save krne ke liyein hume koi saving space chahiyein
// jaha par data save hojaayein and ye save krne ke liye unhe kuchh naam bhi dena padga and isiliyein humein variables and constants banaane padte hai taaki data save hojaae and unka koi naam bhi ho taaki hum baad mein unhe access kar paayein

// var a = 12;

// var c = 22;

// const b = 30;

// b = 20;

// console.log(a, b);

// var discount = 10;

// discount = 22;

// const dis = 12;

// dis = 23;
