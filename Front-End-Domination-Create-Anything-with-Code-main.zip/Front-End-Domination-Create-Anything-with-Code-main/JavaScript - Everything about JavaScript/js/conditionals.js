// conditionals = if else else-if ternary operator switch case

// 99 % if else else-if

// 1% - ternary operator

// jab bhi apko program mein decision lena ho, k aage ka execution kaisa ho t whaha par if else else-if use hota hai

// var age = 18;

// if (age > 18) {
//   console.log("age is greater than 18");
// } else {
//   console.log("age is less than or equal to 18");
// }

// if mein humesha true ya false aata hai

// truthy value

// har value ko true ya false banaya jaa sakta hai, ye depend krta hai, ki wo value ka type kya hai, agar wo value truthy hai to true banegi and falsy hai to false

// null undefined NaN 0 "" '' document.all false

// baaki sab truthy

// if (true) {
//   console.log(true);
// }

// if (12) {
//   console.log(12);
// }

// if (null) {
//   console.log(true);
// }

// if ("lucky") {
//   console.log(true);
// }

// if (12 > 13) {
//   console.log("hey");
// } else {
//   console.log("hello");
// }

// if (12 > 13) console.log("hey");

// if (12 > 13) {
//   console.log("hey");
// } else if (12 > 14) {
//   console.log("greater value");
// } else if (12 > 15) {
//   console.log("less value");
// } else {
//   console.log("false");
// }
