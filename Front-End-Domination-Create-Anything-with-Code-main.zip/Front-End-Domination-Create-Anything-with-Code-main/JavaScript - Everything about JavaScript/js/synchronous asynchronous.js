// synchronous asynchronous
// synchronous code mein humesha line by line chlta hai
// async code line by line nahi chalta, saara async code ek saath shuru kar diya jaata hai and jo pehle complete ho jayein uska answer de diya jaata hai.

// indepth
