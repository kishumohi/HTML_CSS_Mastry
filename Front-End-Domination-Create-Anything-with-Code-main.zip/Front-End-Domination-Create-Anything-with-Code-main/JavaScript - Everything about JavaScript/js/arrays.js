// arrays

// what

// array matlab jab bhi aapko ek ya ek se jaada value ek saath rakhni ho

// var user1 = 'lucky';
// var user2 = 'harshita';
// var user3 = 'harsh';

// var users = ["harsh", "harshita", "harshika", "akansha", "rishi"];

// indexing 0 1 ....

// console.log(users);

// console.log(users[2]);

// console.log((users = 5));
// console.log(users[100]);

// console.log(users.length);

// console.log(typeof users);

// how

// var arr = [1,2,3,4,5,function(){},[],'3'];

// why

// a lot of times the data is in the shape of more than member, to contain all data altogether, we can save it in an array

// loop with array

// how to loop an array and do something with each element

var arr = [1, 2, 3, 4, 5, 6];

// add all numbers
// count all members

// var sum = 0;

// arr.forEach((el) => (sum += el));

// console.log(sum);
