// datatypes & beyond

// types matlab data ka roop

// lucky - string
// 12 - integer
// 12.3 - float
// 22.0 - float
// true - boolean
// a - character

//  types - two types

// primitive vs reference

// 12, 12.4 , lucky, true, a, null, undefined

// references
// [] {} ()

// var a;
// var a = 12;
// var a = 12.1;
// var a = true;
// var a = []; // references
// var a = false;
// var a = null;
// var a = undefined;
// var a = function () {}; // references

// var a = 12;

// var b = 20;

// b += 2;

// console.log(a, b);

// value vs reference

var arr = [1, 2, 3, 4, 5];

// var b = arr;

// spread
var b = [...arr];

b.pop();
console.log(arr, b);

var ar = [12, 13, 14, 15];

var gh = [1, 2, 3];
var ba = [...gh];

var c = ";";
console.log(c);
