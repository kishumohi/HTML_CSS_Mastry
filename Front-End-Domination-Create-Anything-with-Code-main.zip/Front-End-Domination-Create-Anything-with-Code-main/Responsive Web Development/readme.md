\*Responsive website using HTML and CSS

--> Understanding Units - px - % - vw,vh - vmax,vmin - em,rem

--> Layout of website - absolute vs flex

--> flexbox - Display flex - aligning items in x and y axis - flex direction - flex wrap

--> CSS Media Queries - min height, min width - min width, max width

--> Key points to keep in mind to make website responsive

1. CSS flexbox
2. CSS Units
3. Responsive Typography
4. Mobile-First Approach
5. Flexible Images and Media

Practice! Practice! Practice!
