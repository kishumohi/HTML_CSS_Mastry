width & height
color & bg color
units - px % vw vh em rem
max-width & max-height
font-family
font-size
line-height
text-align
padding
margin
border
display
position
background
flex
pseudo-elements
:: before
:: after
:: first-line
:: first-letter
:: selection

pseudo-classes
:hover
:active
:visited
:focus
:nth-child(n)

animation
media queries
