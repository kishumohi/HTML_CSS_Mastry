// DEVELOPER PROBLEMS

// blocking scroll until something happens

document.querySelector("#hide").addEventListener("click", () => {
  document.body.classList.toggle("overflow-hidden");
});

// custom tooltip
