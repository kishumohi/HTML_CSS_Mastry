// DEVELOPER PROBLEMS

// Debugging a TypeError: Cannot read property 'X' of undefined:

// var obj = {};

// obj.name; // no errors

// obj.name.age; // error

// optional chaining

// obj?.name;
// obj?.name?.age;

// Working with Local Storage
// Handling Asynchronous Operations
// blocking scroll until something happens
// custom tooltip
